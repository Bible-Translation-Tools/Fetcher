**Thank you so much for submitting a suggested change.**
 
**If the  issue is about a particular verse  or passage, we ask that you title the issue starting with the 3 letter code of the book followed by the chapter number, colon, and verse number(s), and then give some indication of what the issue is about. For example:**
 
PSA 10:7 "his tongue injures and destroys"

PHP 1:9-11  Remove sentence breaks?
 
**If the issue is about a particular word or expression that occurs throughout the Bible, please simply use a title appropriate to the issue. For example:**
 
”Saints" or ”Believers”

In footnotes, change ”omit” to ”does not have”
 
**Then please explain the issue in this box, giving an example from the ULB as  it stands now and a suggestion for how to fix it.**

**Formatting: If you want a line break, put two spaces after the line and hit the return key.**

